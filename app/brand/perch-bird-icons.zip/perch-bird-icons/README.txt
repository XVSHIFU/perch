栖点 / 小鸟 01 图标

采用第二张参考图左上角 01，通过图像编辑提取整理。
perch-bird-master.png：透明底高分辨率母版。
perch-bird-*.png：透明标志尺寸。
perch-app-*.png：浅底桌面图标。
perch-app.ico：Windows 多尺寸应用图标。
perch-bird.ico：透明底多尺寸图标。

本包为 PNG/ICO 位图资源，不冒充可编辑路径 SVG。
16px 下细腿和羽毛留白会有所损失，建议常规应用展示使用 32px 及以上。
